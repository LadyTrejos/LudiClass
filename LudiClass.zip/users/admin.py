from django.contrib import admin
from users.models import Topic, Material, Activity, User

admin.site.register(Topic)
admin.site.register(Material)
admin.site.register(Activity)
admin.site.register(User)
