const HOSTNAME = "https://ludiclass.herokuapp.com"
export default HOSTNAME;